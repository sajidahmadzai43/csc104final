<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Email configuration
    $to = "SAHMADZAI86297@uat.edu";
    $subject = "New Contact Form Submission from $name";
    $body = "
        <html>
        <head>
            <title>New Contact Message</title>
        </head>
        <body>
            <h2>New Contact Form Submission</h2>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Message:</strong><br>$message</p>
        </body>
        </html>
    ";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: <$email>" . "\r\n";

    // Send email
    if (mail($to, $subject, $body, $headers)) {
        echo "<script>alert('Thank you for your message! We will get back to you soon.'); window.location.href='contact.html';</script>";
    } else {
        echo "<script>alert('Sorry, something went wrong. Please try again.'); window.location.href='contact.html';</script>";
    }
}
?>
