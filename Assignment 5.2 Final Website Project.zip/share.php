<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $story = $_POST['story'];

    // Email configuration
    $to = "SAHMADZAI86297@uat.edu";
    $subject = "New Gardening Story Submission from $name";
    $message = "
        <html>
        <head>
            <title>New Gardening Story</title>
        </head>
        <body>
            <h2>New Gardening Story Submission</h2>
            <p><strong>Name:</strong> $name</p>
            <p><strong>Email:</strong> $email</p>
            <p><strong>Story:</strong><br>$story</p>
        </body>
        </html>
    ";
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: <$email>" . "\r\n";

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        echo "<script>alert('Thank you for sharing your story!'); window.location.href='share.html';</script>";
    } else {
        echo "<script>alert('Sorry, something went wrong. Please try again.'); window.location.href='share.html';</script>";
    }
}
?>
